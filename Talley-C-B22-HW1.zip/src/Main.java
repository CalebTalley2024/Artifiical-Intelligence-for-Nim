
public class Main {

    // 1: User
    // 2: CPU
    public static void main(String[] args) {


        Board GameBoard = new Board();

        GameBoard.run();



    }
}




